package vlt

import (
	"fmt"
	"os"
	"path/filepath"
	"regexp"
	"strings"
)

// Wikilink represents a parsed [[...]] or ![[...]] reference in a note.
type Wikilink struct {
	Title   string // note title (e.g., "Session Operating Mode")
	Heading string // optional heading without # (e.g., "Section")
	BlockID string // optional block ID without ^ (e.g., "my-block")
	Display string // optional display text without | (e.g., "alias")
	Embed   bool   // true if ![[...]] (transclusion)
	Raw     string // original matched text including [[ ]]
}

// wikiLinkPattern matches wikilinks and embeds: [[Title]], ![[Title]],
// [[Title#Heading]], [[Title#^block-id]], [[Title|Display]],
// [[Title#Heading|Display]], [[Title#^block-id|Display]].
var wikiLinkPattern = regexp.MustCompile(`(!?)\[\[([^\]#|]+?)(?:#(\^?[^\]|]*))?(?:\|([^\]]*))?\]\]`)

// ParseWikilinks extracts all wikilinks and embeds from text.
// Content inside inert zones (fenced code blocks, etc.) is masked
// before extraction so those references are ignored.
func ParseWikilinks(text string) []Wikilink {
	text = MaskInertContent(text)
	matches := wikiLinkPattern.FindAllStringSubmatch(text, -1)
	links := make([]Wikilink, 0, len(matches))
	for _, m := range matches {
		wl := Wikilink{
			Embed: m[1] == "!",
			Title: strings.TrimSpace(m[2]),
			Raw:   m[0],
		}
		if len(m) > 3 && m[3] != "" {
			fragment := m[3]
			if strings.HasPrefix(fragment, "^") {
				wl.BlockID = fragment[1:] // strip the ^ prefix
			} else {
				wl.Heading = fragment
			}
		}
		if len(m) > 4 {
			wl.Display = m[4]
		}
		links = append(links, wl)
	}
	return links
}

// ReplaceWikilinks replaces all wikilinks and embeds referencing oldTitle
// with newTitle, preserving the !prefix, #heading, and |display text.
// Case-insensitive to match Obsidian's link resolution behavior.
func ReplaceWikilinks(text, oldTitle, newTitle string) string {
	pattern := regexp.MustCompile(
		`(?i)(!?)\[\[` + regexp.QuoteMeta(oldTitle) +
			`((?:#[^\]|]*)?)` +
			`((?:\|[^\]]*)?)` +
			`\]\]`)
	return pattern.ReplaceAllString(text, `${1}[[`+newTitle+`${2}${3}]]`)
}

// updateVaultLinks scans all .md files in vaultDir and replaces wikilinks
// from oldTitle to newTitle. Returns the number of files modified.
// If reg is non-nil, updated files are registered for integrity tracking.
func updateVaultLinks(vaultDir, oldTitle, newTitle string, reg *Registry) (int, error) {
	modified := 0

	err := filepath.WalkDir(vaultDir, func(path string, d os.DirEntry, err error) error {
		if err != nil {
			return nil
		}

		if skipHiddenDir(path, d, vaultDir) {
			return filepath.SkipDir
		}
		name := d.Name()
		if d.IsDir() || !strings.HasSuffix(name, ".md") {
			return nil
		}

		data, err := os.ReadFile(path)
		if err != nil {
			return nil
		}

		text := string(data)
		updated := ReplaceWikilinks(text, oldTitle, newTitle)
		if updated != text {
			updatedBytes := []byte(updated)
			if err := atomicWriteFile(path, updatedBytes, 0644); err != nil {
				return fmt.Errorf("failed to update %s: %w", path, err)
			}
			if reg != nil {
				reg.register(vaultDir, path, updatedBytes)
			}
			modified++
		}
		return nil
	})

	return modified, err
}

// mdLinkPattern matches markdown-style links to .md files: [text](path.md) or [text](path.md#heading)
var mdLinkPattern = regexp.MustCompile(`\[([^\]]*)\]\(([^)]+\.md(?:#[^)]*)?)\)`)

// updateVaultMdLinks scans all .md files in the vault and updates
// markdown-style [text](path.md) links when a file is moved/renamed.
// oldRelPath and newRelPath are vault-relative paths.
// Returns the number of files modified.
// If reg is non-nil, updated files are registered for integrity tracking.
func updateVaultMdLinks(vaultDir, oldRelPath, newRelPath string, reg *Registry) (int, error) {
	modified := 0

	err := filepath.WalkDir(vaultDir, func(path string, d os.DirEntry, err error) error {
		if err != nil {
			return nil
		}

		if skipHiddenDir(path, d, vaultDir) {
			return filepath.SkipDir
		}
		name := d.Name()
		if d.IsDir() || !strings.HasSuffix(name, ".md") {
			return nil
		}

		data, err := os.ReadFile(path)
		if err != nil {
			return nil
		}

		text := string(data)
		fileDir, _ := filepath.Rel(vaultDir, filepath.Dir(path))

		updated := mdLinkPattern.ReplaceAllStringFunc(text, func(match string) string {
			sub := mdLinkPattern.FindStringSubmatch(match)
			if len(sub) < 3 {
				return match
			}

			linkText := sub[1]
			linkTarget := sub[2]

			// Split off fragment (#heading)
			fragment := ""
			if idx := strings.Index(linkTarget, "#"); idx >= 0 {
				fragment = linkTarget[idx:]
				linkTarget = linkTarget[:idx]
			}

			// Resolve the link target relative to the file containing it
			var resolvedTarget string
			if filepath.IsAbs(linkTarget) {
				return match // absolute paths: leave alone
			}
			resolvedTarget = filepath.Join(fileDir, linkTarget)
			resolvedTarget = filepath.Clean(resolvedTarget)

			// Check if this link points to the old path
			if resolvedTarget != filepath.Clean(oldRelPath) {
				return match
			}

			// Compute the new relative path from the referencing file to the new location
			newTarget, err := filepath.Rel(fileDir, newRelPath)
			if err != nil {
				return match
			}
			// filepath.Rel may produce paths without ./ prefix; keep them clean
			newTarget = filepath.Clean(newTarget)

			return "[" + linkText + "](" + newTarget + fragment + ")"
		})

		if updated != text {
			updatedBytes := []byte(updated)
			if err := atomicWriteFile(path, updatedBytes, 0644); err != nil {
				return fmt.Errorf("failed to update %s: %w", path, err)
			}
			if reg != nil {
				reg.register(vaultDir, path, updatedBytes)
			}
			modified++
		}
		return nil
	})

	return modified, err
}

// FindBacklinks returns relative paths of notes that contain wikilinks or
// embeds referencing the given title. Case-insensitive.
// Content inside inert zones (fenced code blocks, etc.) is masked before
// matching so that references inside code blocks are ignored.
func FindBacklinks(vaultDir, title string) ([]string, error) {
	return findBacklinksAny(vaultDir, []string{title})
}

// findBacklinksAny returns relative paths of notes containing wikilinks or
// embeds referencing ANY of the given targets (e.g. a note's title and its
// path form "folder/Note"). Case-insensitive.
func findBacklinksAny(vaultDir string, targets []string) ([]string, error) {
	quoted := make([]string, len(targets))
	for i, t := range targets {
		quoted[i] = regexp.QuoteMeta(t)
	}
	pattern := regexp.MustCompile(
		`(?i)!?\[\[(?:` + strings.Join(quoted, "|") + `)` +
			`(?:#[^\]|]*)?(?:\|[^\]]*)?` +
			`\]\]`)

	var results []string

	err := filepath.WalkDir(vaultDir, func(path string, d os.DirEntry, err error) error {
		if err != nil {
			return nil
		}

		if skipHiddenDir(path, d, vaultDir) {
			return filepath.SkipDir
		}
		name := d.Name()
		if d.IsDir() || !strings.HasSuffix(name, ".md") {
			return nil
		}

		data, err := os.ReadFile(path)
		if err != nil {
			return nil
		}

		masked := MaskInertContent(string(data))
		if pattern.MatchString(masked) {
			relPath, _ := filepath.Rel(vaultDir, path)
			results = append(results, relPath)
		}
		return nil
	})

	return results, err
}
