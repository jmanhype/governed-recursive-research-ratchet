// vlt -- fast Obsidian vault CLI (no app required)
//
// Drop-in replacement for the obsidian CLI that operates directly on the
// filesystem. No Obsidian app dependency, no Electron round-trips.
//
// Discovers vaults from the Obsidian config file, resolves notes by title
// or alias, and performs file, property, link, and tag operations.
package main

import (
	"fmt"
	"io"
	"os"
	"strings"

	vlt "github.com/paivot-ai/vlt"
)

// version is set at build time via ldflags. Falls back to "dev" for
// untagged builds (e.g., go install without -ldflags).
var version = "dev"

var knownCommands = map[string]bool{
	"read": true, "search": true, "create": true,
	"append": true, "prepend": true, "write": true, "patch": true, "move": true, "delete": true,
	"property:set": true, "property:remove": true, "properties": true,
	"backlinks": true, "links": true, "orphans": true, "unresolved": true,
	"tags": true, "tag": true, "files": true,
	"tasks": true, "daily": true, "templates": true, "templates:apply": true,
	"bookmarks": true, "bookmarks:add": true, "bookmarks:remove": true,
	"integrity:baseline": true, "integrity:acknowledge": true, "integrity:status": true,
	"uri":    true,
	"vaults": true, "help": true, "version": true,
}

// knownFlags lists every bare-word flag the CLI accepts. Anything else is an
// error: a silently ignored typo ("permanant", "delette") would otherwise
// change behaviour without any signal to the caller.
var knownFlags = map[string]bool{
	"silent": true, "permanent": true, "delete": true, "timestamps": true,
	"counts": true, "total": true, "done": true, "pending": true,
	"follow": true, "backlinks": true, "force": true,
	"--strict-flock": true, "--json": true, "--yaml": true, "--csv": true,
	"--tsv": true, "--tree": true, "--help": true, "-h": true, "--version": true,
}

func main() {
	if len(os.Args) < 2 {
		usage()
		os.Exit(1)
	}

	cmd, params, flags, err := parseArgs(os.Args[1:])
	if err != nil {
		die("%v", err)
	}

	if cmd == "help" || flags["--help"] || flags["-h"] {
		usage()
		return
	}
	if cmd == "version" || flags["--version"] {
		fmt.Println("vlt " + version)
		return
	}
	format := outputFormat(flags)

	if cmd == "vaults" {
		vaults, err := vlt.DiscoverVaults()
		if err != nil {
			die("%v", err)
		}
		printVaults(vaults, format)
		return
	}
	if cmd == "" {
		die("no command specified. Run 'vlt help' for usage.")
	}

	// Resolve vault
	vaultName := params["vault"]
	if vaultName == "" {
		vaultName = os.Getenv("VLT_VAULT")
	}
	if vaultName == "" {
		die("vault not specified. Use vault=\"<name>\" or set VLT_VAULT env var.")
	}

	v, err := vlt.OpenByName(vaultName)
	if err != nil {
		die("%v", err)
	}

	// Write commands always acquire an exclusive lock. Read commands skip
	// locking by default so they are never blocked by a concurrent writer.
	// Pass --strict-flock to restore shared-lock behaviour for reads.
	unlock := func() {} // no-op for lock-free reads
	if vlt.IsWriteCommand(cmd) || flags["--strict-flock"] {
		var lockErr error
		unlock, lockErr = vlt.LockVault(v.Dir(), vlt.IsWriteCommand(cmd))
		if lockErr != nil {
			die("cannot lock vault: %v", lockErr)
		}
		// The integrity registry was loaded before the lock was held; a
		// concurrent writer may have flushed entries in between. Reload so
		// this process's flushes do not erase them.
		v.ReloadRegistry()
	}
	defer unlock()

	ts := timestampsEnabled(flags["timestamps"])

	// Dispatch
	switch cmd {
	case "read":
		err = dispatchRead(v, params, flags)
	case "search":
		err = dispatchSearch(v, params, format)
	case "create":
		err = dispatchCreate(v, params, flags["silent"], ts)
	case "append":
		err = dispatchAppend(v, params, ts)
	case "prepend":
		err = dispatchPrepend(v, params, ts)
	case "write":
		err = dispatchWrite(v, params, ts)
	case "patch":
		err = dispatchPatch(v, params, flags["delete"], ts)
	case "move":
		err = dispatchMove(v, params, flags["force"])
	case "delete":
		err = dispatchDelete(v, params, flags["permanent"])
	case "property:set":
		err = dispatchPropertySet(v, params)
	case "property:remove":
		err = dispatchPropertyRemove(v, params)
	case "properties":
		err = dispatchProperties(v, params, format)
	case "backlinks":
		err = dispatchBacklinks(v, params, format)
	case "links":
		err = dispatchLinks(v, params, format)
	case "orphans":
		err = dispatchOrphans(v, format)
	case "unresolved":
		err = dispatchUnresolved(v, format)
	case "tags":
		err = dispatchTags(v, params, flags["counts"], format)
	case "tag":
		err = dispatchTag(v, params, format)
	case "files":
		err = dispatchFiles(v, params, flags["total"], format)
	case "tasks":
		err = dispatchTasks(v, params, flags)
	case "daily":
		err = dispatchDaily(v, params)
	case "templates":
		err = dispatchTemplates(v, params, format)
	case "templates:apply":
		err = dispatchTemplatesApply(v, params)
	case "bookmarks":
		err = dispatchBookmarks(v, format)
	case "bookmarks:add":
		err = dispatchBookmarksAdd(v, params)
	case "bookmarks:remove":
		err = dispatchBookmarksRemove(v, params)
	case "integrity:baseline":
		err = dispatchIntegrityBaseline(v)
	case "integrity:acknowledge":
		err = dispatchIntegrityAcknowledge(v, params)
	case "integrity:status":
		err = dispatchIntegrityStatus(v, format)
	case "uri":
		err = dispatchURI(v, vaultName, params)
	default:
		die("unknown command: %s", cmd)
	}

	if err != nil {
		die("%v", err)
	}
}

// parseArgs splits CLI arguments into a command name, key=value parameters,
// and bare-word flags. It preserves the obsidian CLI's key="value" syntax.
// Unknown bare words are an error rather than silently ignored.
func parseArgs(args []string) (string, map[string]string, map[string]bool, error) {
	params := make(map[string]string)
	flags := make(map[string]bool)
	var cmd string

	for _, arg := range args {
		if i := strings.Index(arg, "="); i > 0 {
			key := arg[:i]
			val := arg[i+1:]
			params[key] = stripQuotePair(val)
		} else if knownCommands[arg] && cmd == "" {
			cmd = arg
		} else if knownFlags[arg] {
			flags[arg] = true
		} else {
			return "", nil, nil, fmt.Errorf("unknown command or flag: %q%s", arg, suggestArg(arg))
		}
	}

	return cmd, params, flags, nil
}

// stripQuotePair removes exactly one matching pair of surrounding quotes.
// This handles programmatic invocation where shell quote removal did not
// happen, without mangling values that legitimately contain quotes.
func stripQuotePair(s string) string {
	if len(s) >= 2 && (s[0] == '"' || s[0] == '\'') && s[len(s)-1] == s[0] {
		return s[1 : len(s)-1]
	}
	return s
}

// suggestArg returns a " (did you mean ...?)" hint when arg is within edit
// distance 2 of a known command or flag.
func suggestArg(arg string) string {
	best := ""
	bestDist := 3 // only suggest within distance 2
	for _, set := range []map[string]bool{knownCommands, knownFlags} {
		for known := range set {
			if d := editDistance(arg, known); d < bestDist {
				bestDist = d
				best = known
			}
		}
	}
	if best == "" {
		return ""
	}
	return fmt.Sprintf(" (did you mean %q?)", best)
}

// editDistance computes the Levenshtein distance between two strings.
func editDistance(a, b string) int {
	if len(a) == 0 {
		return len(b)
	}
	if len(b) == 0 {
		return len(a)
	}
	prev := make([]int, len(b)+1)
	cur := make([]int, len(b)+1)
	for j := range prev {
		prev[j] = j
	}
	for i := 1; i <= len(a); i++ {
		cur[0] = i
		for j := 1; j <= len(b); j++ {
			cost := 1
			if a[i-1] == b[j-1] {
				cost = 0
			}
			cur[j] = min(prev[j]+1, min(cur[j-1]+1, prev[j-1]+cost))
		}
		prev, cur = cur, prev
	}
	return prev[len(b)]
}

func die(format string, args ...any) {
	fmt.Fprintf(os.Stderr, "vlt: "+format+"\n", args...)
	os.Exit(1)
}

// readStdinIfPiped reads all of stdin if it's being piped (not a terminal).
// Returns empty string if stdin is a terminal.
func readStdinIfPiped() string {
	stat, _ := os.Stdin.Stat()
	if stat.Mode()&os.ModeCharDevice != 0 {
		return "" // stdin is a terminal, not piped
	}
	data, err := io.ReadAll(os.Stdin)
	if err != nil {
		return ""
	}
	return string(data)
}

// timestampsEnabled returns true if timestamps should be applied,
// based on the explicit flag or the VLT_TIMESTAMPS environment variable.
func timestampsEnabled(flag bool) bool {
	if flag {
		return true
	}
	return os.Getenv("VLT_TIMESTAMPS") == "1"
}

func usage() {
	fmt.Print(`vlt -- fast Obsidian vault CLI (no app required)

Usage:
  vlt vault="<name>" <command> [args...]

File commands:
  read           file="<title>" [heading="<heading>"] [follow] [backlinks]  Read a note (with linked context)
  create         name="<title>" path="<path>" [content=...] [silent] [timestamps]  Create a note
  append         file="<title>" [content="<text>"] [timestamps]      Append to end of note
  prepend        file="<title>" [content="<text>"] [timestamps]      Prepend after frontmatter
  write          file="<title>" [content="<text>"] [timestamps]      Replace body (preserve frontmatter)
  patch          file="<title>" heading="<heading>" [content="<text>"] [delete] [timestamps]  Section edit
  patch          file="<title>" line="<N>" [content="<text>"] [delete] [timestamps]           Line edit
  patch          file="<title>" line="<N-M>" [content="<text>"] [delete] [timestamps]         Line range edit
  patch          file="<title>" old="<text>" new="<text>" [heading=|line=] [timestamps]       Find and replace
  move           path="<from>" to="<to>" [force]             Move/rename (updates wiki + md links; refuses to overwrite without force)
  delete         file="<title>" [permanent]                  Trash (or permanently delete; trash names never collide)
  files          [folder="<dir>"] [ext="<ext>"] [total]      List vault files
  daily          [date="YYYY-MM-DD"]                         Create or read daily note

Property commands:
  properties     file="<title>"                              Show all frontmatter
  property:set   file="<title>" name="<key>" value="<val>"   Set a frontmatter property
  property:remove file="<title>" name="<key>"                Remove a frontmatter property

Link commands:
  backlinks      file="<title>"                              Notes linking to this note
  links          file="<title>"                              Outgoing links (flags broken)
  orphans                                                    Notes with no incoming links
  unresolved                                                 Broken links across vault

Tag commands:
  tags           [sort="count"] [counts]                     List all tags in vault
  tag            tag="<tagname>"                             Find notes with tag (+ subtags)

Task commands:
  tasks          [file="<title>"] [path="<dir>"] [done] [pending]  List tasks (checkboxes)

Template commands:
  templates                                                    List available templates
  templates:apply template="<name>" name="<title>" path="<path>"  Create note from template

Bookmark commands:
  bookmarks                                                    List bookmarked file paths
  bookmarks:add  file="<title>"                                Add a bookmark for a note
  bookmarks:remove file="<title>"                              Remove a bookmark

Integrity commands:
  integrity:baseline                                             Register all vault files for integrity tracking
  integrity:status                                               Show integrity status of all registered files
  integrity:acknowledge file="<title>"                           Re-register a file after external modification
  integrity:acknowledge since="<duration>"                       Re-register files modified within duration (e.g., "1h")

URI commands:
  uri            file="<title>" [heading="<H>"] [block="<B>"]  Generate obsidian:// URI for a note

Search:
  search         query="<term> [key:value]" [context="N"]    Search by title, content, properties
  search         regex="<pattern>" [context="N"]              Search by regex (case-insensitive)
                                                              context=N shows N lines before/after each match

Other:
  vaults                                                     List discovered vaults

Options:
  vault="<name>"   Vault name (from Obsidian config), absolute path, or VLT_VAULT env var.
  silent           Suppress success output on create ("already exists" still goes to stderr).
  permanent        Hard delete instead of .trash.
  force            Allow move to overwrite an existing destination.
  delete           Remove heading+content or line(s) instead of replacing (patch).
  old/new          Find-and-replace within scope (heading, line, or file-wide if neither).
  heading          Accepts "## Section" (exact level) or "Section" (any level).
  timestamps       Auto-manage created_at/updated_at frontmatter (or set VLT_TIMESTAMPS=1).
  counts           Show note counts with tags.
  total            Show count instead of listing files.
  done             Show only completed tasks.
  pending          Show only pending tasks.
  follow           Include full content of forward-linked notes (read only).
  backlinks        Include full content of notes linking to this one (read only).
  --strict-flock   Acquire advisory flock for reads too (default: writes only).
                   Lock waits time out after 10s; tune with VLT_LOCK_TIMEOUT ("30s", "0" = wait forever).
  --json           Output in JSON format.
  --yaml           Output in YAML format.
  --csv            Output in CSV format.
  --tsv            Output in TSV (tab-separated values) format.
  --tree           Output file lists as a hierarchical directory tree.

Content from stdin:
  If content= is omitted for create/append/prepend/write, content is read from stdin.

Search filters:
  Property filters can be embedded in search queries: query="term [key:value]"
  Multiple filters: query="architecture [status:active] [type:decision]"
  Filter-only: query="[status:active]"
  Regex search: regex="arch\w+ure" (case-insensitive by default)
  Regex + filters: regex="pattern" query="[status:active]"
  If both query= and regex= provide text, regex takes precedence (with a warning).

Wikilink support:
  [[Note]], [[Note#Heading]], [[Note#^block-id]], [[Note|Display]], ![[Embed]]
  Block references (^block-id) are fully supported in parsing, rename, and backlinks.

Library usage:
  import "github.com/paivot-ai/vlt"

  vault, _ := vlt.OpenByName("MyVault")
  result, _ := vault.Read("Session Operating Mode", "")
  fmt.Print(result.Content)           // result.Integrity has tamper status
  results, _ := vault.Search(vlt.SearchOptions{Query: "architecture"})
  _ = vault.Append("Daily Log", "New entry", false)

Examples:
  vlt vault="AgentVault" read file="Operating Mode"
  vlt vault="AgentVault" read file="Design Doc" heading="## Architecture"
  vlt vault="AgentVault" read file="Design Doc" follow
  vlt vault="AgentVault" read file="Session Operating Mode" backlinks
  vlt vault="ProjectVault" search query="architecture"
  vlt vault="ProjectVault" search query="[status:active] [type:decision]"
  vlt vault="AgentVault" create name="My Note" path="_inbox/My Note.md" content="# Hello" silent
  echo "## Update" | vlt vault="AgentVault" append file="My Note"
  vlt vault="AgentVault" prepend file="My Note" content="New section at top"
  vlt vault="AgentVault" write file="My Note" content="# Replacement body"
  vlt vault="ProjectVault" patch file="Note" heading="## Section" content="new content"
  vlt vault="ProjectVault" patch file="Note" heading="## Section" delete
  vlt vault="ProjectVault" patch file="Note" line="5" content="replacement line"
  vlt vault="ProjectVault" patch file="Note" line="5-10" content="replacement block"
  vlt vault="ProjectVault" patch file="Note" line="5" delete
  vlt vault="ProjectVault" patch file="Note" old="old text" new="new text"
  vlt vault="ProjectVault" patch file="Note" heading="Section" old="find" new="replace"
  vlt vault="AgentVault" move path="_inbox/Old.md" to="decisions/New.md"
  vlt vault="AgentVault" delete file="Old Draft"
  vlt vault="AgentVault" delete file="Old Draft" permanent
  vlt vault="ProjectVault" properties file="My Decision"
  vlt vault="ProjectVault" property:set file="Note" name="status" value="archived"
  vlt vault="ProjectVault" property:remove file="Note" name="confidence"
  vlt vault="AgentVault" backlinks file="Operating Mode"
  vlt vault="ProjectVault" links file="Developer Guide"
  vlt vault="ProjectVault" orphans
  vlt vault="ProjectVault" unresolved
  vlt vault="AgentVault" tags counts sort="count"
  vlt vault="AgentVault" tag tag="project"
  vlt vault="ProjectVault" files folder="docs"
  vlt vault="ProjectVault" files total
  vlt vault="ProjectVault" tasks
  vlt vault="ProjectVault" tasks file="Project Plan" pending
  vlt vault="ProjectVault" tasks path="projects" --json
  vlt vault="AgentVault" daily
  vlt vault="AgentVault" daily date="2025-01-15"
  vlt vault="ProjectVault" orphans --json
  vlt vault="ProjectVault" search query="architecture" --csv
  vlt vault="ProjectVault" search query="architecture" context="2"
  vlt vault="ProjectVault" search query="architecture [status:active]" context="1" --json
  vlt vault="AgentVault" search regex="arch\w+ure"
  vlt vault="AgentVault" search regex="\d{4}-\d{2}-\d{2}" context="2"
  vlt vault="AgentVault" search regex="pattern" query="[status:active]"
  vlt vault="AgentVault" create name="Note" path="_inbox/Note.md" content="# Note" timestamps
  vlt vault="AgentVault" append file="Note" content="more" timestamps
  VLT_TIMESTAMPS=1 vlt vault="AgentVault" write file="Note" content="# New Body"
  vlt vault="ProjectVault" templates
  vlt vault="ProjectVault" templates --json
  vlt vault="ProjectVault" templates:apply template="Meeting Notes" name="Q1 Planning" path="meetings/Q1 Planning.md"
  vlt vault="AgentVault" bookmarks
  vlt vault="AgentVault" bookmarks --json
  vlt vault="AgentVault" bookmarks:add file="Important Note"
  vlt vault="AgentVault" bookmarks:remove file="Old Note"
  vlt vault="ProjectVault" uri file="Design Doc"
  vlt vault="ProjectVault" uri file="Design Doc" heading="Architecture"
  vlt vault="ProjectVault" uri file="Note" block="block-id"
  vlt vaults
`)
}
