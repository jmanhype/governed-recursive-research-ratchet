package vlt

import (
	"fmt"
	"net/url"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strings"
	"time"
)

// SearchResult holds a single search match.
type SearchResult struct {
	Title   string
	RelPath string
}

// ContextMatch holds a single line-level match with surrounding context.
type ContextMatch struct {
	File    string   // relative path
	Line    int      // 1-based line number of the match
	Match   string   // the matched line text
	Context []string // surrounding lines including the match line
}

// lineRange represents an inclusive range of 0-based line indices.
type lineRange struct {
	start int
	end   int
}

// LinkInfo holds outgoing link information.
type LinkInfo struct {
	Target string `json:"target"`
	Path   string `json:"path"`
	Broken bool   `json:"broken"`
}

// UnresolvedLink holds an unresolved link and its source.
type UnresolvedLink struct {
	Target string `json:"target"`
	Source string `json:"source"`
}

// SearchOptions parameterises a Search or SearchWithContext call.
type SearchOptions struct {
	Query    string
	Regex    string
	Path     string
	ContextN int
}

// PatchOptions parameterises a Patch call.
type PatchOptions struct {
	Heading    string
	LineSpec   string
	Content    string
	Old        string // Find-and-replace: text to find
	New        string // Find-and-replace: replacement text
	Delete     bool
	Timestamps bool
}

// MoveResult is returned by Move and reports what changed.
type MoveResult struct {
	OldTitle         string
	NewTitle         string
	WikilinksUpdated int
	MdLinksUpdated   int
}

// ErrNoteExists is returned by Create when a note already exists at the target path.
var ErrNoteExists = fmt.Errorf("note already exists")

// ErrDestinationExists is returned by Move when the destination already exists
// and force was not requested.
var ErrDestinationExists = fmt.Errorf("destination already exists")

// sectionBounds holds the line range of a section identified by findSection.
// HeadingLine is the 0-based index of the heading line itself.
// ContentStart is the 0-based index of the first content line after the heading.
// ContentEnd is the 0-based index one past the last content line (exclusive).
// If the section has no content, ContentStart == ContentEnd.
type sectionBounds struct {
	HeadingLine  int
	ContentStart int
	ContentEnd   int
}

// -----------------------------------------------------------------
// Unexported helpers
// -----------------------------------------------------------------

// findMatchLines returns 0-based line indices where query appears (case-insensitive).
func findMatchLines(lines []string, query string) []int {
	queryLower := strings.ToLower(query)
	var matches []int
	for i, line := range lines {
		if strings.Contains(strings.ToLower(line), queryLower) {
			matches = append(matches, i)
		}
	}
	return matches
}

// findMatchLinesRegex returns 0-based line indices where the compiled regex matches.
func findMatchLinesRegex(lines []string, re *regexp.Regexp) []int {
	var matches []int
	for i, line := range lines {
		if re.MatchString(line) {
			matches = append(matches, i)
		}
	}
	return matches
}

// expandAndMerge takes match line indices and a context radius, producing merged
// non-overlapping ranges clamped to [0, totalLines).
func expandAndMerge(matchLines []int, contextN int, totalLines int) []lineRange {
	if len(matchLines) == 0 {
		return nil
	}

	var ranges []lineRange
	for _, m := range matchLines {
		start := m - contextN
		if start < 0 {
			start = 0
		}
		end := m + contextN
		if end >= totalLines {
			end = totalLines - 1
		}
		ranges = append(ranges, lineRange{start, end})
	}

	// Merge overlapping or adjacent ranges
	merged := []lineRange{ranges[0]}
	for i := 1; i < len(ranges); i++ {
		last := &merged[len(merged)-1]
		if ranges[i].start <= last.end+1 {
			if ranges[i].end > last.end {
				last.end = ranges[i].end
			}
		} else {
			merged = append(merged, ranges[i])
		}
	}

	return merged
}

// searchFilterPattern matches [key:value] property filters in search queries.
var searchFilterPattern = regexp.MustCompile(`\[(\w+):([^\]]+)\]`)

// parseSearchQuery splits a query into text terms and property filters.
// Filters are [key:value] pairs extracted from the query string.
func parseSearchQuery(query string) (text string, filters map[string]string) {
	filters = make(map[string]string)
	matches := searchFilterPattern.FindAllStringSubmatch(query, -1)
	for _, m := range matches {
		filters[m[1]] = m[2]
	}
	text = strings.TrimSpace(searchFilterPattern.ReplaceAllString(query, ""))
	return
}

// headingLevel returns the Markdown heading level (number of leading # chars).
// Returns 0 if the line is not a heading.
func headingLevel(line string) int {
	trimmed := strings.TrimSpace(line)
	if !strings.HasPrefix(trimmed, "#") {
		return 0
	}
	level := 0
	for _, ch := range trimmed {
		if ch == '#' {
			level++
		} else {
			break
		}
	}
	// Must be followed by a space or end of line to be a valid heading
	if level >= len(trimmed) || trimmed[level] == ' ' {
		return level
	}
	return 0
}

// headingText extracts the text portion of a heading, stripping the # prefix
// and leading space. Returns empty string for non-headings.
func headingText(line string) string {
	trimmed := strings.TrimSpace(line)
	lvl := headingLevel(trimmed)
	if lvl == 0 {
		return ""
	}
	if lvl >= len(trimmed) {
		return ""
	}
	return strings.TrimSpace(trimmed[lvl:])
}

// findSection locates a heading in the given lines and returns its bounds.
// The heading parameter may include the # prefix (e.g., "## Section A") for
// exact level matching, or omit it (e.g., "Section A") for level-insensitive
// matching. Heading text match is always case-insensitive and trims whitespace.
// The section extends from the heading to the line before the next heading of
// equal or higher level (or EOF). This operates on RAW content, not masked.
// Returns an error if the heading is not found or if multiple headings match.
func findSection(lines []string, heading string) (sectionBounds, error) {
	heading = strings.TrimSpace(heading)
	targetLevel := headingLevel(heading)

	// Level-insensitive mode: heading has no # prefix.
	levelInsensitive := targetLevel == 0
	if levelInsensitive {
		// Require non-empty text.
		if heading == "" {
			return sectionBounds{}, fmt.Errorf("empty heading")
		}
	}

	// Determine the text to match against (without # prefix).
	var searchText string
	if levelInsensitive {
		searchText = strings.ToLower(heading)
	} else {
		searchText = strings.ToLower(headingText(heading))
	}

	// First pass: find all headings whose text matches.
	type match struct {
		line  int
		level int
	}
	var matches []match
	for i, line := range lines {
		lvl := headingLevel(line)
		if lvl == 0 {
			continue
		}
		lineText := strings.ToLower(headingText(line))
		if lineText == searchText {
			if levelInsensitive || lvl == targetLevel {
				matches = append(matches, match{line: i, level: lvl})
			}
		}
	}

	if len(matches) == 0 {
		return sectionBounds{}, fmt.Errorf("heading %q not found", heading)
	}
	if len(matches) > 1 {
		nums := make([]string, len(matches))
		for j, m := range matches {
			nums[j] = fmt.Sprintf("%d", m.line+1)
		}
		return sectionBounds{}, fmt.Errorf("heading %q is ambiguous: found %d matches at lines %s",
			heading, len(matches), strings.Join(nums, ", "))
	}

	// Exactly one match.
	m := matches[0]
	contentStart := m.line + 1
	contentEnd := len(lines) // default: extends to EOF

	for j := contentStart; j < len(lines); j++ {
		lvl := headingLevel(lines[j])
		if lvl > 0 && lvl <= m.level {
			contentEnd = j
			break
		}
	}

	return sectionBounds{
		HeadingLine:  m.line,
		ContentStart: contentStart,
		ContentEnd:   contentEnd,
	}, nil
}

// parseLineSpec parses a line specification like "5" or "5-10" into start and end
// line numbers (1-based, inclusive).
func parseLineSpec(spec string) (start, end int, err error) {
	if idx := strings.Index(spec, "-"); idx >= 0 {
		startStr := spec[:idx]
		endStr := spec[idx+1:]
		start, err = parseInt(startStr)
		if err != nil {
			return 0, 0, fmt.Errorf("invalid line range start: %s", startStr)
		}
		end, err = parseInt(endStr)
		if err != nil {
			return 0, 0, fmt.Errorf("invalid line range end: %s", endStr)
		}
		return start, end, nil
	}

	start, err = parseInt(spec)
	if err != nil {
		return 0, 0, fmt.Errorf("invalid line number: %s", spec)
	}
	return start, start, nil
}

// parseInt parses a string as a positive integer.
func parseInt(s string) (int, error) {
	n := 0
	for _, ch := range s {
		if ch < '0' || ch > '9' {
			return 0, fmt.Errorf("not a number: %s", s)
		}
		n = n*10 + int(ch-'0')
	}
	if n == 0 {
		return 0, fmt.Errorf("not a positive number: %s", s)
	}
	return n, nil
}

// ParseInt0 parses a string as a non-negative integer (0 is allowed).
// Exported for use by the CLI dispatch layer.
func ParseInt0(s string) (int, error) {
	if s == "" {
		return 0, fmt.Errorf("empty string")
	}
	n := 0
	for _, ch := range s {
		if ch < '0' || ch > '9' {
			return 0, fmt.Errorf("not a number: %s", s)
		}
		n = n*10 + int(ch-'0')
	}
	return n, nil
}

// encodeURIComponent percent-encodes a string for use as a URI query parameter
// value. Encodes spaces as %20, slashes as %2F, ampersands as %26, plus as %2B,
// and other reserved characters. Uses url.QueryEscape (which encodes everything
// aggressively) then replaces + with %20 since Obsidian expects %20 for spaces.
func encodeURIComponent(s string) string {
	return strings.ReplaceAll(url.QueryEscape(s), "+", "%20")
}

// -----------------------------------------------------------------
// Vault methods
// -----------------------------------------------------------------

// Read returns the contents of a note resolved by title, along with its
// integrity status.
// If heading is non-empty, only the specified section is returned
// (heading line + content through the next same-or-higher-level heading).
func (v *Vault) Read(title, heading string) (ReadResult, error) {
	v.mu.RLock()
	defer v.mu.RUnlock()

	path, err := v.resolve(title)
	if err != nil {
		return ReadResult{}, err
	}

	data, err := os.ReadFile(path)
	if err != nil {
		return ReadResult{}, err
	}

	status := v.registry.verify(v.dir, path, data)

	if heading == "" {
		return ReadResult{Content: string(data), Integrity: status}, nil
	}

	// Heading-scoped read: find the section and return heading + content.
	lines := strings.Split(string(data), "\n")
	bounds, err := findSection(lines, heading)
	if err != nil {
		return ReadResult{}, fmt.Errorf("%s in %q", err, title)
	}

	// Extract from heading line through end of section.
	section := lines[bounds.HeadingLine:bounds.ContentEnd]
	output := strings.Join(section, "\n")

	// Ensure exactly one trailing newline (matches file convention).
	if !strings.HasSuffix(output, "\n") {
		output += "\n"
	}

	return ReadResult{Content: output, Integrity: status}, nil
}

// LinkedNote holds a related note's title and content, returned by ReadFollow
// and ReadWithBacklinks.
type LinkedNote struct {
	Title   string // note title (stem of filename)
	Path    string // vault-relative path
	Content string // full file content
}

// ReadFollow returns the content of the requested note (with integrity status)
// plus the full content of every note it forward-links to (depth 1). This lets
// callers retrieve a note's entire link neighborhood in a single call.
func (v *Vault) ReadFollow(title, heading string) (ReadResult, []LinkedNote, error) {
	v.mu.RLock()
	defer v.mu.RUnlock()

	path, err := v.resolve(title)
	if err != nil {
		return ReadResult{}, nil, err
	}

	data, err := os.ReadFile(path)
	if err != nil {
		return ReadResult{}, nil, err
	}

	status := v.registry.verify(v.dir, path, data)

	primary := string(data)
	if heading != "" {
		lines := strings.Split(primary, "\n")
		bounds, err := findSection(lines, heading)
		if err != nil {
			return ReadResult{}, nil, fmt.Errorf("%s in %q", err, title)
		}
		section := lines[bounds.HeadingLine:bounds.ContentEnd]
		primary = strings.Join(section, "\n")
		if !strings.HasSuffix(primary, "\n") {
			primary += "\n"
		}
	}

	// Parse outgoing wikilinks from the full file (even if heading-scoped)
	links := ParseWikilinks(string(data))
	seen := make(map[string]bool)
	var linked []LinkedNote
	for _, wl := range links {
		if wl.Title == title || seen[wl.Title] {
			continue
		}
		seen[wl.Title] = true

		linkedPath, resolveErr := v.resolve(wl.Title)
		if resolveErr != nil {
			continue // skip broken links
		}
		linkedData, readErr := os.ReadFile(linkedPath)
		if readErr != nil {
			continue
		}
		relPath, _ := filepath.Rel(v.dir, linkedPath)
		linked = append(linked, LinkedNote{
			Title:   wl.Title,
			Path:    relPath,
			Content: string(linkedData),
		})
	}

	return ReadResult{Content: primary, Integrity: status}, linked, nil
}

// ReadWithBacklinks returns the content of the requested note (with integrity
// status) plus the full content of every note that links TO it (depth 1 backlinks).
func (v *Vault) ReadWithBacklinks(title, heading string) (ReadResult, []LinkedNote, error) {
	v.mu.RLock()
	defer v.mu.RUnlock()

	path, err := v.resolve(title)
	if err != nil {
		return ReadResult{}, nil, err
	}

	data, err := os.ReadFile(path)
	if err != nil {
		return ReadResult{}, nil, err
	}

	status := v.registry.verify(v.dir, path, data)

	primary := string(data)
	if heading != "" {
		lines := strings.Split(primary, "\n")
		bounds, err := findSection(lines, heading)
		if err != nil {
			return ReadResult{}, nil, fmt.Errorf("%s in %q", err, title)
		}
		section := lines[bounds.HeadingLine:bounds.ContentEnd]
		primary = strings.Join(section, "\n")
		if !strings.HasSuffix(primary, "\n") {
			primary += "\n"
		}
	}

	blPaths, err := findBacklinksAny(v.dir, v.backlinkTargets(title))
	if err != nil {
		return ReadResult{Content: primary, Integrity: status}, nil, err
	}

	var linked []LinkedNote
	for _, relPath := range blPaths {
		absPath := filepath.Join(v.dir, relPath)
		blData, readErr := os.ReadFile(absPath)
		if readErr != nil {
			continue
		}
		blTitle := strings.TrimSuffix(filepath.Base(relPath), ".md")
		linked = append(linked, LinkedNote{
			Title:   blTitle,
			Path:    relPath,
			Content: string(blData),
		})
	}

	return ReadResult{Content: primary, Integrity: status}, linked, nil
}

// Search finds notes whose title or content matches opts.Query or opts.Regex.
// Property filters embedded in opts.Query ([key:value]) are also applied.
// Returns results without context lines. For context-aware search use SearchWithContext.
func (v *Vault) Search(opts SearchOptions) ([]SearchResult, error) {
	v.mu.RLock()
	defer v.mu.RUnlock()

	query := opts.Query
	regexParam := opts.Regex

	if query == "" && regexParam == "" {
		return nil, fmt.Errorf("search requires Query or Regex to be set")
	}

	// Compile regex if provided.
	var re *regexp.Regexp
	useRegex := regexParam != ""

	if useRegex {
		var compileErr error
		re, compileErr = regexp.Compile("(?i)" + regexParam)
		if compileErr != nil {
			return nil, fmt.Errorf("invalid regex %q: %v", regexParam, compileErr)
		}

		// If both query and regex provided, warn and use regex for text matching.
		if query != "" {
			fmt.Fprintf(os.Stderr, "vlt: both Query and Regex provided; Regex takes precedence for text matching\n")
		}
	}

	// Parse property filters from query.
	var textQuery string
	var filters map[string]string
	if query != "" {
		textQuery, filters = parseSearchQuery(query)
	} else {
		filters = make(map[string]string)
	}

	queryLower := strings.ToLower(textQuery)

	searchRoot := v.dir
	if opts.Path != "" {
		var pathErr error
		searchRoot, pathErr = safePath(v.dir, opts.Path)
		if pathErr != nil {
			return nil, fmt.Errorf("search path: %w", pathErr)
		}
		if _, err := os.Stat(searchRoot); os.IsNotExist(err) {
			return nil, fmt.Errorf("path filter %q not found in vault", opts.Path)
		}
	}

	hasTextQuery := useRegex || queryLower != ""
	hasFilters := len(filters) > 0

	if !hasTextQuery && !hasFilters {
		return nil, fmt.Errorf("search requires Query or Regex to be set")
	}

	var results []SearchResult

	err := filepath.WalkDir(searchRoot, func(path string, d os.DirEntry, err error) error {
		if err != nil {
			return nil
		}

		if skipHiddenDir(path, d, searchRoot) {
			return filepath.SkipDir
		}

		name := d.Name()
		if d.IsDir() || !strings.HasSuffix(name, ".md") {
			return nil
		}

		title := strings.TrimSuffix(name, ".md")
		relPath, _ := filepath.Rel(v.dir, path)

		// Read file content (needed for both text search and property filters).
		data, readErr := os.ReadFile(path)
		if readErr != nil {
			return nil
		}
		content := string(data)

		// Check property filters first if present.
		if hasFilters {
			yaml, _, hasFM := ExtractFrontmatter(content)
			if !hasFM {
				return nil // no frontmatter, can't match property filters
			}
			for k, fv := range filters {
				got, ok := FrontmatterGetValue(yaml, k)
				if !ok || !strings.EqualFold(got, fv) {
					return nil // filter doesn't match
				}
			}
		}

		// If no text query, property filters already passed.
		if !hasTextQuery {
			results = append(results, SearchResult{Title: title, RelPath: relPath})
			return nil
		}

		// Determine matches based on regex or substring.
		var titleMatches, contentMatches bool
		if useRegex {
			titleMatches = re.MatchString(title)
			contentMatches = re.MatchString(content)
		} else {
			titleMatches = strings.Contains(strings.ToLower(title), queryLower)
			contentMatches = strings.Contains(strings.ToLower(content), queryLower)
		}

		if !titleMatches && !contentMatches {
			return nil
		}

		results = append(results, SearchResult{Title: title, RelPath: relPath})
		return nil
	})

	if err != nil {
		return nil, err
	}

	return results, nil
}

// SearchWithContext finds notes matching opts.Query or opts.Regex and returns
// line-level matches with opts.ContextN surrounding lines on each side.
func (v *Vault) SearchWithContext(opts SearchOptions) ([]ContextMatch, error) {
	v.mu.RLock()
	defer v.mu.RUnlock()

	query := opts.Query
	regexParam := opts.Regex

	if query == "" && regexParam == "" {
		return nil, fmt.Errorf("search requires Query or Regex to be set")
	}

	// Compile regex if provided.
	var re *regexp.Regexp
	useRegex := regexParam != ""

	if useRegex {
		var compileErr error
		re, compileErr = regexp.Compile("(?i)" + regexParam)
		if compileErr != nil {
			return nil, fmt.Errorf("invalid regex %q: %v", regexParam, compileErr)
		}

		if query != "" {
			fmt.Fprintf(os.Stderr, "vlt: both Query and Regex provided; Regex takes precedence for text matching\n")
		}
	}

	// Parse property filters from query.
	var textQuery string
	var filters map[string]string
	if query != "" {
		textQuery, filters = parseSearchQuery(query)
	} else {
		filters = make(map[string]string)
	}

	queryLower := strings.ToLower(textQuery)

	searchRoot := v.dir
	if opts.Path != "" {
		var pathErr error
		searchRoot, pathErr = safePath(v.dir, opts.Path)
		if pathErr != nil {
			return nil, fmt.Errorf("search path: %w", pathErr)
		}
		if _, err := os.Stat(searchRoot); os.IsNotExist(err) {
			return nil, fmt.Errorf("path filter %q not found in vault", opts.Path)
		}
	}

	hasTextQuery := useRegex || queryLower != ""
	hasFilters := len(filters) > 0

	if !hasTextQuery && !hasFilters {
		return nil, fmt.Errorf("search requires Query or Regex to be set")
	}

	contextN := opts.ContextN

	var contextResults []ContextMatch

	err := filepath.WalkDir(searchRoot, func(path string, d os.DirEntry, err error) error {
		if err != nil {
			return nil
		}

		if skipHiddenDir(path, d, searchRoot) {
			return filepath.SkipDir
		}

		name := d.Name()
		if d.IsDir() || !strings.HasSuffix(name, ".md") {
			return nil
		}

		title := strings.TrimSuffix(name, ".md")
		relPath, _ := filepath.Rel(v.dir, path)

		// Read file content.
		data, readErr := os.ReadFile(path)
		if readErr != nil {
			return nil
		}
		content := string(data)

		// Check property filters first if present.
		if hasFilters {
			yaml, _, hasFM := ExtractFrontmatter(content)
			if !hasFM {
				return nil
			}
			for k, fv := range filters {
				got, ok := FrontmatterGetValue(yaml, k)
				if !ok || !strings.EqualFold(got, fv) {
					return nil
				}
			}
		}

		// Determine title/content matches.
		var titleMatches, contentMatches bool
		if useRegex {
			titleMatches = re.MatchString(title)
			contentMatches = re.MatchString(content)
		} else {
			titleMatches = strings.Contains(strings.ToLower(title), queryLower)
			contentMatches = strings.Contains(strings.ToLower(content), queryLower)
		}

		if !hasTextQuery {
			// Filters matched but no text query -- synthetic title match.
			contextResults = append(contextResults, ContextMatch{
				File:    relPath,
				Line:    0,
				Match:   title,
				Context: nil,
			})
			return nil
		}

		if !titleMatches && !contentMatches {
			return nil
		}

		// Context mode: find line-level matches.
		lines := strings.Split(content, "\n")
		var matchLineIdxs []int
		if useRegex {
			matchLineIdxs = findMatchLinesRegex(lines, re)
		} else {
			matchLineIdxs = findMatchLines(lines, textQuery)
		}

		if len(matchLineIdxs) > 0 {
			ranges := expandAndMerge(matchLineIdxs, contextN, len(lines))
			for _, r := range ranges {
				for i := r.start; i <= r.end; i++ {
					isMatch := false
					for _, m := range matchLineIdxs {
						if m == i {
							isMatch = true
							break
						}
					}
					if isMatch {
						ctxStart := i - contextN
						if ctxStart < 0 {
							ctxStart = 0
						}
						ctxEnd := i + contextN
						if ctxEnd >= len(lines) {
							ctxEnd = len(lines) - 1
						}
						var ctxLines []string
						for j := ctxStart; j <= ctxEnd; j++ {
							ctxLines = append(ctxLines, lines[j])
						}
						contextResults = append(contextResults, ContextMatch{
							File:    relPath,
							Line:    i + 1, // 1-based
							Match:   lines[i],
							Context: ctxLines,
						})
					}
				}
			}
		} else if titleMatches {
			// Title matched but no content match -- synthetic context match.
			contextResults = append(contextResults, ContextMatch{
				File:    relPath,
				Line:    0,
				Match:   title,
				Context: nil,
			})
		}

		return nil
	})

	if err != nil {
		return nil, err
	}

	return contextResults, nil
}

// atomicWriteFile writes data to path atomically: it writes to a temporary
// file in the same directory, then renames it into place. POSIX rename is
// atomic on the same filesystem, so a concurrent lock-free reader always
// observes either the complete old file or the complete new file -- never a
// truncated or empty intermediate state. This guarantee is what makes
// lock-free reads safe (readers acquire no flock by default).
func atomicWriteFile(path string, data []byte, perm os.FileMode) error {
	dir := filepath.Dir(path)
	// Leading dot keeps the temp file out of markdown discovery (it neither
	// ends in .md nor is visible to dot-skipping walkers) during the window
	// before the rename completes.
	tmp, err := os.CreateTemp(dir, "."+filepath.Base(path)+".tmp-*")
	if err != nil {
		return err
	}
	tmpName := tmp.Name()
	// Remove the temp file unless the rename below claims it.
	defer func() {
		if tmpName != "" {
			os.Remove(tmpName)
		}
	}()

	if _, err := tmp.Write(data); err != nil {
		tmp.Close()
		return err
	}
	if err := tmp.Chmod(perm); err != nil {
		tmp.Close()
		return err
	}
	if err := tmp.Sync(); err != nil {
		tmp.Close()
		return err
	}
	if err := tmp.Close(); err != nil {
		return err
	}
	if err := os.Rename(tmpName, path); err != nil {
		return err
	}
	tmpName = "" // rename succeeded; ownership transferred to path
	return nil
}

// Create creates a new note at the given path within the vault.
// Returns ErrNoteExists if the note already exists.
// When timestamps is true (or VLT_TIMESTAMPS=1), created_at and updated_at
// are added to frontmatter.
func (v *Vault) Create(name, path, content string, silent, timestamps bool) error {
	v.mu.Lock()
	defer v.mu.Unlock()

	if name == "" || path == "" {
		return fmt.Errorf("create requires name and path")
	}

	fullPath, err := safePath(v.dir, path)
	if err != nil {
		return fmt.Errorf("create: %w", err)
	}

	// Don't overwrite existing notes.
	if _, err := os.Stat(fullPath); err == nil {
		return ErrNoteExists
	}

	if timestampsEnabled(timestamps) {
		content = ensureTimestamps(content, true, time.Now())
	}

	// Ensure parent directory exists.
	if err := os.MkdirAll(filepath.Dir(fullPath), 0755); err != nil {
		return err
	}

	contentBytes := []byte(content)
	if err := atomicWriteFile(fullPath, contentBytes, 0644); err != nil {
		return err
	}
	v.registry.register(v.dir, fullPath, contentBytes)
	v.invalidateIndex()
	return nil
}

// Append adds content to the end of an existing note. The write is atomic
// (read, concatenate, rename into place) so lock-free readers never observe
// a partially appended file. If the existing content does not end with a
// newline, one is inserted so appended content starts on its own line.
// When timestamps is true (or VLT_TIMESTAMPS=1), updated_at is refreshed.
func (v *Vault) Append(title, content string, timestamps bool) error {
	v.mu.Lock()
	defer v.mu.Unlock()

	path, err := v.resolve(title)
	if err != nil {
		return err
	}

	data, err := os.ReadFile(path)
	if err != nil {
		return err
	}

	text := string(data)
	if text != "" && !strings.HasSuffix(text, "\n") && content != "" && !strings.HasPrefix(content, "\n") {
		text += "\n"
	}
	result := text + content

	if timestampsEnabled(timestamps) {
		result = ensureTimestamps(result, false, time.Now())
	}

	resultBytes := []byte(result)
	if err := atomicWriteFile(path, resultBytes, 0644); err != nil {
		return err
	}
	v.registry.register(v.dir, path, resultBytes)
	v.invalidateIndex()
	return nil
}

// Prepend inserts content at the top of a note, after frontmatter if present.
// When timestamps is true (or VLT_TIMESTAMPS=1), updated_at is refreshed.
func (v *Vault) Prepend(title, content string, timestamps bool) error {
	v.mu.Lock()
	defer v.mu.Unlock()

	path, err := v.resolve(title)
	if err != nil {
		return err
	}

	data, err := os.ReadFile(path)
	if err != nil {
		return err
	}

	text := string(data)
	_, bodyStart, hasFM := ExtractFrontmatter(text)

	// Ensure prepended content ends with a newline so it does not merge
	// with the first body line.
	if content != "" && !strings.HasSuffix(content, "\n") {
		content += "\n"
	}

	lines := strings.Split(text, "\n")
	var result string

	if hasFM && bodyStart <= len(lines) {
		before := strings.Join(lines[:bodyStart], "\n")
		after := strings.Join(lines[bodyStart:], "\n")
		result = before + "\n" + content + after
	} else {
		result = content + text
	}

	if timestampsEnabled(timestamps) {
		result = ensureTimestamps(result, false, time.Now())
	}

	resultBytes := []byte(result)
	if err := atomicWriteFile(path, resultBytes, 0644); err != nil {
		return err
	}
	v.registry.register(v.dir, path, resultBytes)
	v.invalidateIndex()
	return nil
}

// Write replaces the body content of an existing note, preserving frontmatter.
// If the note has no frontmatter, the entire file content is replaced.
// When timestamps is true (or VLT_TIMESTAMPS=1), updated_at is refreshed.
func (v *Vault) Write(title, content string, timestamps bool) error {
	v.mu.Lock()
	defer v.mu.Unlock()

	path, err := v.resolve(title)
	if err != nil {
		return err
	}

	data, err := os.ReadFile(path)
	if err != nil {
		return err
	}

	text := string(data)
	_, bodyStart, hasFM := ExtractFrontmatter(text)

	var result string
	if hasFM {
		lines := strings.Split(text, "\n")
		frontmatter := strings.Join(lines[:bodyStart], "\n")
		result = frontmatter + "\n" + content
	} else {
		result = content
	}

	// Files conventionally end with a newline; preserve that invariant.
	if result != "" && !strings.HasSuffix(result, "\n") {
		result += "\n"
	}

	if timestampsEnabled(timestamps) {
		result = ensureTimestamps(result, false, time.Now())
	}

	resultBytes := []byte(result)
	if err := atomicWriteFile(path, resultBytes, 0644); err != nil {
		return err
	}
	v.registry.register(v.dir, path, resultBytes)
	return nil
}

// Patch performs surgical edits to a note: heading-targeted, line-targeted,
// or old/new text replacement. opts.Delete controls whether content is removed
// or replaced. When opts.Old is set, find-and-replace is used within the scope
// (heading, line, or entire file body if neither is set). Old must match exactly
// once within the scope; zero or multiple matches are errors.
// When opts.Timestamps is true (or VLT_TIMESTAMPS=1), updated_at is refreshed.
func (v *Vault) Patch(title string, opts PatchOptions) error {
	v.mu.Lock()
	defer v.mu.Unlock()

	path, err := v.resolve(title)
	if err != nil {
		return err
	}

	data, err := os.ReadFile(path)
	if err != nil {
		return err
	}

	text := string(data)
	lines := strings.Split(text, "\n")

	heading := opts.Heading
	lineSpec := opts.LineSpec

	// Old/New replacement mode.
	if opts.Old != "" {
		return v.patchOldNew(path, text, lines, opts)
	}

	if heading == "" && lineSpec == "" {
		return fmt.Errorf("patch requires Heading, LineSpec, or Old to be set")
	}

	content := opts.Content

	var result []string

	if heading != "" {
		// Heading-targeted patch.
		bounds, err := findSection(lines, heading)
		if err != nil {
			return fmt.Errorf("%s in %q", err, title)
		}

		if opts.Delete {
			// Delete mode: remove heading + content.
			result = append(result, lines[:bounds.HeadingLine]...)
			result = append(result, lines[bounds.ContentEnd:]...)
		} else {
			// Replace mode: keep heading, replace content.
			result = append(result, lines[:bounds.ContentStart]...)
			if content != "" {
				contentLines := strings.Split(content, "\n")
				result = append(result, contentLines...)
			}
			result = append(result, lines[bounds.ContentEnd:]...)
		}
	} else {
		// Line-targeted patch.
		startLine, endLine, err := parseLineSpec(lineSpec)
		if err != nil {
			return err
		}

		// Validate range (1-based to 0-based).
		if startLine < 1 || endLine < startLine {
			return fmt.Errorf("invalid line specification: %s", lineSpec)
		}
		if startLine > len(lines) {
			return fmt.Errorf("line %d is beyond file length (%d lines); out of range", startLine, len(lines))
		}
		if endLine > len(lines) {
			return fmt.Errorf("line %d is beyond file length (%d lines); out of range", endLine, len(lines))
		}

		// Convert to 0-based.
		start := startLine - 1
		end := endLine // exclusive (endLine is 1-based, so endLine = 0-based + 1)

		if opts.Delete {
			result = append(result, lines[:start]...)
			result = append(result, lines[end:]...)
		} else {
			result = append(result, lines[:start]...)
			result = append(result, content)
			result = append(result, lines[end:]...)
		}
	}

	output := strings.Join(result, "\n")

	if timestampsEnabled(opts.Timestamps) {
		output = ensureTimestamps(output, false, time.Now())
	}

	outputBytes := []byte(output)
	if err := atomicWriteFile(path, outputBytes, 0644); err != nil {
		return err
	}
	v.registry.register(v.dir, path, outputBytes)
	v.invalidateIndex()
	return nil
}

// patchOldNew performs find-and-replace within a scoped region. When heading or
// line is set, replacement is scoped to that section. When neither is set, the
// scope is the entire file body (excluding frontmatter). Old must match exactly
// once within the scope; zero or multiple matches are errors.
func (v *Vault) patchOldNew(path, text string, lines []string, opts PatchOptions) error {
	// Determine scope boundaries (0-based line indices, exclusive end).
	scopeStart := 0
	scopeEnd := len(lines)

	if opts.Heading != "" {
		bounds, err := findSection(lines, opts.Heading)
		if err != nil {
			// Extract title from path for error context.
			base := filepath.Base(path)
			title := strings.TrimSuffix(base, filepath.Ext(base))
			return fmt.Errorf("%s in %q", err, title)
		}
		scopeStart = bounds.ContentStart
		scopeEnd = bounds.ContentEnd
	} else if opts.LineSpec != "" {
		startLine, endLine, err := parseLineSpec(opts.LineSpec)
		if err != nil {
			return err
		}
		if startLine < 1 || endLine < startLine || startLine > len(lines) || endLine > len(lines) {
			return fmt.Errorf("invalid line specification: %s", opts.LineSpec)
		}
		scopeStart = startLine - 1
		scopeEnd = endLine
	} else {
		// File-wide scope: skip frontmatter.
		_, bodyStart, _ := ExtractFrontmatter(text)
		scopeStart = bodyStart
	}

	// Build the scoped text and count matches.
	scopeLines := lines[scopeStart:scopeEnd]
	scopeText := strings.Join(scopeLines, "\n")

	count := strings.Count(scopeText, opts.Old)
	if count == 0 {
		return fmt.Errorf("old text not found in scope")
	}
	if count > 1 {
		return fmt.Errorf("old text is ambiguous: found %d matches in scope", count)
	}

	// Perform the single replacement within scope.
	newScopeText := strings.Replace(scopeText, opts.Old, opts.New, 1)
	newScopeLines := strings.Split(newScopeText, "\n")

	// Rebuild the full file.
	var result []string
	result = append(result, lines[:scopeStart]...)
	result = append(result, newScopeLines...)
	result = append(result, lines[scopeEnd:]...)

	output := strings.Join(result, "\n")

	if timestampsEnabled(opts.Timestamps) {
		output = ensureTimestamps(output, false, time.Now())
	}

	outputBytes := []byte(output)
	if err := atomicWriteFile(path, outputBytes, 0644); err != nil {
		return err
	}
	v.registry.register(v.dir, path, outputBytes)
	v.invalidateIndex()
	return nil
}

// Move moves a note from one path to another within the vault.
// Returns ErrDestinationExists if a file already exists at the destination;
// use MoveForce to overwrite. Wikilinks referencing the old title and
// path-form wikilinks ([[folder/Note]]) are updated vault-wide.
// Returns a MoveResult describing what was updated.
func (v *Vault) Move(from, to string) (MoveResult, error) {
	return v.move(from, to, false)
}

// MoveForce is Move but overwrites the destination if it already exists.
func (v *Vault) MoveForce(from, to string) (MoveResult, error) {
	return v.move(from, to, true)
}

func (v *Vault) move(from, to string, force bool) (MoveResult, error) {
	v.mu.Lock()
	defer v.mu.Unlock()

	fromPath, err := safePath(v.dir, from)
	if err != nil {
		return MoveResult{}, fmt.Errorf("move source: %w", err)
	}
	toPath, err := safePath(v.dir, to)
	if err != nil {
		return MoveResult{}, fmt.Errorf("move destination: %w", err)
	}

	if _, err := os.Stat(fromPath); os.IsNotExist(err) {
		return MoveResult{}, fmt.Errorf("source not found: %s", from)
	}

	// Never silently overwrite an existing destination.
	if fromPath != toPath {
		if _, err := os.Stat(toPath); err == nil && !force {
			return MoveResult{}, fmt.Errorf("move destination %s: %w (use force to overwrite)", to, ErrDestinationExists)
		}
	}

	if err := os.MkdirAll(filepath.Dir(toPath), 0755); err != nil {
		return MoveResult{}, err
	}

	oldTitle := strings.TrimSuffix(filepath.Base(from), ".md")
	newTitle := strings.TrimSuffix(filepath.Base(to), ".md")

	if err := os.Rename(fromPath, toPath); err != nil {
		return MoveResult{}, err
	}
	v.invalidateIndex()

	// Deregister old path, register new path.
	v.registry.deregister(v.dir, fromPath)
	if newData, readErr := os.ReadFile(toPath); readErr == nil {
		v.registry.register(v.dir, toPath, newData)
	}

	res := MoveResult{
		OldTitle: oldTitle,
		NewTitle: newTitle,
	}

	// If the filename changed, update title-form wikilinks across the vault.
	if oldTitle != newTitle {
		count, err := updateVaultLinks(v.dir, oldTitle, newTitle, v.registry)
		if err != nil {
			return res, fmt.Errorf("moved file but failed updating links: %w", err)
		}
		res.WikilinksUpdated = count
	}

	// Update path-form wikilinks ([[folder/Note]]) -- these break on any
	// move, including folder-only moves where the title is unchanged.
	oldRelNoExt := strings.TrimSuffix(filepath.ToSlash(filepath.Clean(from)), ".md")
	newRelNoExt := strings.TrimSuffix(filepath.ToSlash(filepath.Clean(to)), ".md")
	if oldRelNoExt != oldTitle && oldRelNoExt != newRelNoExt {
		count, err := updateVaultLinks(v.dir, oldRelNoExt, newRelNoExt, v.registry)
		if err != nil {
			return res, fmt.Errorf("moved file but failed updating path links: %w", err)
		}
		res.WikilinksUpdated += count
	}

	// Update markdown-style [text](path.md) links across the vault.
	mdCount, mdErr := updateVaultMdLinks(v.dir, from, to, v.registry)
	if mdErr != nil {
		return res, fmt.Errorf("moved file but failed updating markdown links: %w", mdErr)
	}
	res.MdLinksUpdated = mdCount

	v.invalidateIndex()
	return res, nil
}

// Delete moves a note to .trash/ (or permanently deletes with permanent=true).
// Returns a human-readable message describing what happened.
func (v *Vault) Delete(title, notePath string, permanent bool) (string, error) {
	v.mu.Lock()
	defer v.mu.Unlock()

	var fullPath string

	if notePath != "" {
		var pathErr error
		fullPath, pathErr = safePath(v.dir, notePath)
		if pathErr != nil {
			return "", fmt.Errorf("delete: %w", pathErr)
		}
	} else if title != "" {
		resolved, err := v.resolve(title)
		if err != nil {
			return "", err
		}
		fullPath = resolved
	} else {
		return "", fmt.Errorf("delete requires file or path to be specified")
	}

	if _, err := os.Stat(fullPath); os.IsNotExist(err) {
		return "", fmt.Errorf("file not found: %s", fullPath)
	}

	relPath, _ := filepath.Rel(v.dir, fullPath)

	if permanent {
		if err := os.Remove(fullPath); err != nil {
			return "", err
		}
		v.registry.deregister(v.dir, fullPath)
		v.invalidateIndex()
		return fmt.Sprintf("deleted: %s", relPath), nil
	}

	trashDir := filepath.Join(v.dir, ".trash")
	if err := os.MkdirAll(trashDir, 0755); err != nil {
		return "", err
	}
	trashName, err := uniqueTrashName(trashDir, filepath.Base(fullPath))
	if err != nil {
		return "", err
	}
	trashPath := filepath.Join(trashDir, trashName)
	if err := os.Rename(fullPath, trashPath); err != nil {
		return "", err
	}
	v.registry.deregister(v.dir, fullPath)
	v.invalidateIndex()
	return fmt.Sprintf("trashed: %s -> .trash/%s", relPath, trashName), nil
}

// uniqueTrashName returns a filename that does not collide with anything
// already in the trash directory. On collision a numeric suffix is appended
// ("Note.md" -> "Note 1.md"), matching Obsidian's behaviour, so trashing a
// note never destroys a previously trashed one.
func uniqueTrashName(trashDir, base string) (string, error) {
	candidate := base
	ext := filepath.Ext(base)
	stem := strings.TrimSuffix(base, ext)
	for i := 1; ; i++ {
		if _, err := os.Stat(filepath.Join(trashDir, candidate)); os.IsNotExist(err) {
			return candidate, nil
		}
		if i > 10000 {
			return "", fmt.Errorf("cannot find free name in .trash for %s", base)
		}
		candidate = fmt.Sprintf("%s %d%s", stem, i, ext)
	}
}

// Properties returns the YAML frontmatter block of a note (with --- delimiters).
func (v *Vault) Properties(title string) (string, error) {
	v.mu.RLock()
	defer v.mu.RUnlock()

	path, err := v.resolve(title)
	if err != nil {
		return "", err
	}

	data, err := os.ReadFile(path)
	if err != nil {
		return "", err
	}

	fm := frontmatterReadAll(string(data))
	return fm, nil
}

// validatePropertyName rejects property names that would corrupt the
// frontmatter block or be unparseable later.
func validatePropertyName(name string) error {
	if name == "" {
		return fmt.Errorf("property name is empty")
	}
	if strings.ContainsAny(name, "\n\r") {
		return fmt.Errorf("property name must not contain newlines")
	}
	if strings.Contains(name, ":") {
		return fmt.Errorf("property name must not contain %q", ":")
	}
	if strings.HasPrefix(name, "-") || strings.HasPrefix(name, " ") || strings.HasPrefix(name, "\t") {
		return fmt.Errorf("property name must not start with %q", string(name[0]))
	}
	return nil
}

// validatePropertyValue rejects values that would break out of the property
// line and corrupt the frontmatter block.
func validatePropertyValue(value string) error {
	if strings.ContainsAny(value, "\n\r") {
		return fmt.Errorf("property value must not contain newlines")
	}
	return nil
}

// PropertySet sets or adds a YAML frontmatter property in a note.
// Only top-level (unindented) keys are matched; nested keys under another
// mapping are never modified.
func (v *Vault) PropertySet(title, name, value string) error {
	v.mu.Lock()
	defer v.mu.Unlock()

	if err := validatePropertyName(name); err != nil {
		return err
	}
	if err := validatePropertyValue(value); err != nil {
		return err
	}

	path, err := v.resolve(title)
	if err != nil {
		return err
	}

	data, err := os.ReadFile(path)
	if err != nil {
		return err
	}

	lines := strings.Split(string(data), "\n")

	// Find frontmatter boundaries (--- ... ---).
	fmStart, fmEnd := -1, -1
	for i, line := range lines {
		if strings.TrimSpace(line) == "---" {
			if fmStart == -1 {
				fmStart = i
			} else {
				fmEnd = i
				break
			}
		}
	}

	if fmStart == -1 || fmEnd == -1 {
		return fmt.Errorf("no frontmatter found in %q", title)
	}

	// Look for an existing top-level property line.
	found := false
	for i := fmStart + 1; i < fmEnd; i++ {
		if isTopLevelKeyLine(lines[i], name) {
			lines[i] = fmt.Sprintf("%s: %s", name, value)
			found = true
			break
		}
	}

	// If not found, insert before closing ---.
	if !found {
		newLine := fmt.Sprintf("%s: %s", name, value)
		lines = append(lines[:fmEnd+1], lines[fmEnd:]...)
		lines[fmEnd] = newLine
	}

	result := strings.Join(lines, "\n")
	resultBytes := []byte(result)
	if err := atomicWriteFile(path, resultBytes, 0644); err != nil {
		return err
	}
	v.registry.register(v.dir, path, resultBytes)
	v.invalidateIndex()
	return nil
}

// PropertyRemove removes a property from a note's frontmatter.
func (v *Vault) PropertyRemove(title, name string) error {
	v.mu.Lock()
	defer v.mu.Unlock()

	path, err := v.resolve(title)
	if err != nil {
		return err
	}

	data, err := os.ReadFile(path)
	if err != nil {
		return err
	}

	text := string(data)
	updated := frontmatterRemoveKey(text, name)

	if updated == text {
		return fmt.Errorf("property %q not found in %q", name, title)
	}

	updatedBytes := []byte(updated)
	if err := atomicWriteFile(path, updatedBytes, 0644); err != nil {
		return err
	}
	v.registry.register(v.dir, path, updatedBytes)
	v.invalidateIndex()
	return nil
}

// Backlinks finds all notes that contain wikilinks to the given title,
// including path-form links ([[folder/Note]]) when the note resolves.
func (v *Vault) Backlinks(title string) ([]string, error) {
	v.mu.RLock()
	defer v.mu.RUnlock()

	return findBacklinksAny(v.dir, v.backlinkTargets(title))
}

// backlinkTargets returns the link spellings that reach the given title:
// the title itself plus, when the note resolves, its vault-relative path
// without extension.
func (v *Vault) backlinkTargets(title string) []string {
	targets := []string{title}
	if path, err := v.resolve(title); err == nil {
		if rel, relErr := filepath.Rel(v.dir, path); relErr == nil {
			relNoExt := strings.TrimSuffix(filepath.ToSlash(rel), ".md")
			if relNoExt != title {
				targets = append(targets, relNoExt)
			}
		}
	}
	return targets
}

// Links lists outgoing wikilinks from a note, reporting which resolve
// and which are broken.
func (v *Vault) Links(title string) ([]LinkInfo, error) {
	v.mu.RLock()
	defer v.mu.RUnlock()

	path, err := v.resolve(title)
	if err != nil {
		return nil, err
	}

	data, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}

	links := ParseWikilinks(string(data))
	if len(links) == 0 {
		return nil, nil
	}

	seen := make(map[string]bool)
	var results []LinkInfo
	for _, link := range links {
		if seen[link.Title] {
			continue
		}
		seen[link.Title] = true

		if rel, ok := v.resolveLink(link.Title); ok {
			results = append(results, LinkInfo{Target: link.Title, Path: rel, Broken: false})
		} else {
			results = append(results, LinkInfo{Target: link.Title, Path: "", Broken: true})
		}
	}

	return results, nil
}

// Orphans finds notes that have no incoming wikilinks or embeds.
// Both title-form ([[Note]]) and path-form ([[folder/Note]]) references
// count, as do references to a note's frontmatter aliases.
func (v *Vault) Orphans() ([]string, error) {
	v.mu.RLock()
	defer v.mu.RUnlock()

	idx := v.index()

	// Collect referenced targets and per-note aliases in one pass.
	type noteInfo struct {
		relPath string
		title   string
		aliases []string
	}
	notes := make([]noteInfo, 0, len(idx.mdRel))
	referenced := make(map[string]bool)

	for _, rel := range idx.mdRel {
		title := strings.TrimSuffix(filepath.Base(rel), ".md")
		info := noteInfo{relPath: filepath.FromSlash(rel), title: title}

		data, err := os.ReadFile(filepath.Join(v.dir, filepath.FromSlash(rel)))
		if err == nil {
			text := string(data)
			yaml, _, hasFM := ExtractFrontmatter(text)
			if hasFM {
				info.aliases = FrontmatterGetList(yaml, "aliases")
			}
			for _, link := range ParseWikilinks(text) {
				referenced[strings.ToLower(filepath.ToSlash(link.Title))] = true
			}
		}

		notes = append(notes, info)
	}

	// Find orphans: notes whose title, path, and aliases are all unreferenced.
	var orphans []string
	for _, note := range notes {
		if referenced[strings.ToLower(note.title)] {
			continue
		}
		relNoExt := strings.ToLower(strings.TrimSuffix(filepath.ToSlash(note.relPath), ".md"))
		if referenced[relNoExt] {
			continue
		}
		aliasReferenced := false
		for _, a := range note.aliases {
			if referenced[strings.ToLower(a)] {
				aliasReferenced = true
				break
			}
		}
		if !aliasReferenced {
			orphans = append(orphans, note.relPath)
		}
	}

	sort.Strings(orphans)
	return orphans, nil
}

// Unresolved finds all broken wikilinks across the vault. A link resolves if
// it matches a note title, a vault-relative path (with or without extension),
// an attachment filename (e.g. [[photo.png]]), or a frontmatter alias.
func (v *Vault) Unresolved() ([]UnresolvedLink, error) {
	v.mu.RLock()
	defer v.mu.RUnlock()

	idx := v.index()

	var results []UnresolvedLink
	seenTargets := make(map[string]bool)

	for _, rel := range idx.mdRel {
		data, err := os.ReadFile(filepath.Join(v.dir, filepath.FromSlash(rel)))
		if err != nil {
			continue
		}

		for _, link := range ParseWikilinks(string(data)) {
			lower := strings.ToLower(filepath.ToSlash(link.Title))
			if seenTargets[lower] {
				continue
			}
			if _, ok := v.resolveLink(link.Title); !ok {
				seenTargets[lower] = true
				results = append(results, UnresolvedLink{Target: link.Title, Source: filepath.FromSlash(rel)})
			}
		}
	}

	return results, nil
}

// Files lists files in the vault, optionally filtered by folder and extension.
func (v *Vault) Files(folder, ext string) ([]string, error) {
	v.mu.RLock()
	defer v.mu.RUnlock()

	if ext == "" {
		ext = "md"
	}

	searchRoot := v.dir
	if folder != "" {
		var pathErr error
		searchRoot, pathErr = safePath(v.dir, folder)
		if pathErr != nil {
			return nil, fmt.Errorf("files folder: %w", pathErr)
		}
		if _, err := os.Stat(searchRoot); os.IsNotExist(err) {
			return nil, fmt.Errorf("folder not found: %s", folder)
		}
	}

	var files []string

	filepath.WalkDir(searchRoot, func(path string, d os.DirEntry, err error) error {
		if err != nil {
			return nil
		}
		if skipHiddenDir(path, d, searchRoot) {
			return filepath.SkipDir
		}
		name := d.Name()
		if d.IsDir() || !strings.HasSuffix(name, "."+ext) {
			return nil
		}

		relPath, _ := filepath.Rel(v.dir, path)
		files = append(files, relPath)
		return nil
	})

	sort.Strings(files)
	return files, nil
}

// URI generates an obsidian:// URI for a note resolved by title.
// The URI format is: obsidian://open?vault=VAULT&file=PATH[&heading=H][&block=B]
// Vault name and file path are URL-encoded. The .md extension is stripped.
// Path separators use forward slash (/).
func (v *Vault) URI(vaultName, title, heading, block string) (string, error) {
	v.mu.RLock()
	defer v.mu.RUnlock()

	path, err := v.resolve(title)
	if err != nil {
		return "", err
	}

	// Get relative path from vault root, strip .md extension.
	relPath, _ := filepath.Rel(v.dir, path)
	relPath = strings.TrimSuffix(relPath, ".md")

	// Normalize path separators to forward slash (for Windows compatibility).
	relPath = filepath.ToSlash(relPath)

	// URL-encode vault name and file path.
	encodedVault := encodeURIComponent(vaultName)
	encodedFile := encodeURIComponent(relPath)

	uri := fmt.Sprintf("obsidian://open?vault=%s&file=%s", encodedVault, encodedFile)

	// Optional heading fragment.
	if heading != "" {
		uri += "&heading=" + encodeURIComponent(heading)
	}

	// Optional block fragment.
	if block != "" {
		uri += "&block=" + encodeURIComponent(block)
	}

	return uri, nil
}
