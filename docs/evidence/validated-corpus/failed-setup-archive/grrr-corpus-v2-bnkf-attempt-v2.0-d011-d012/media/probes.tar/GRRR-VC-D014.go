package vlt

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

var _ = time.Second

func writeProbe(t *testing.T, path, content string) {
	t.Helper()
	if err := os.WriteFile(path, []byte(content), 0644); err != nil { t.Fatal(err) }
}

func requireProbe(t *testing.T, err error) {
	t.Helper()
	if err != nil { t.Fatal(err) }
}

func readFileProbe(t *testing.T, path string) string {
	t.Helper()
	data, err := os.ReadFile(path)
	if err != nil { t.Fatal(err) }
	return string(data)
}

func requireRelProbe(t *testing.T, root, path, expected string) {
	t.Helper()
	got, err := filepath.Rel(root, path)
	if err != nil { t.Fatal(err) }
	if filepath.ToSlash(got) != expected { t.Fatalf("path %q, want %q", got, expected) }
}

func requireContainsProbe(t *testing.T, values []string, expected string) {
	t.Helper()
	for _, value := range values { if strings.Contains(value, expected) { return } }
	t.Fatalf("missing %q in %#v", expected, values)
}

func vaultProbe(t *testing.T) *Vault {
	t.Helper()
	dir := t.TempDir()
	return &Vault{dir: dir, registry: openRegistry(dir)}
}

func TestGRRRD014(t *testing.T) {
values := FrontmatterGetList("aliases: [\"Quoted\", Plain]", "aliases")
if len(values) != 2 || values[0] != "Quoted" || values[1] != "Plain" { t.Fatalf("quoted alias survived: %#v", values) }
}
