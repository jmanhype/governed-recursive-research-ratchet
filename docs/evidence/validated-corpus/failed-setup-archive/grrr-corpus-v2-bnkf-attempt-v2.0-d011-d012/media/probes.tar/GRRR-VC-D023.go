package vlt

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

var _ = time.Second

func writeProbe(t *testing.T, path, content string) {
	t.Helper()
	if err := os.WriteFile(path, []byte(content), 0644); err != nil { t.Fatal(err) }
}

func requireProbe(t *testing.T, err error) {
	t.Helper()
	if err != nil { t.Fatal(err) }
}

func readFileProbe(t *testing.T, path string) string {
	t.Helper()
	data, err := os.ReadFile(path)
	if err != nil { t.Fatal(err) }
	return string(data)
}

func requireRelProbe(t *testing.T, root, path, expected string) {
	t.Helper()
	got, err := filepath.Rel(root, path)
	if err != nil { t.Fatal(err) }
	if filepath.ToSlash(got) != expected { t.Fatalf("path %q, want %q", got, expected) }
}

func requireContainsProbe(t *testing.T, values []string, expected string) {
	t.Helper()
	for _, value := range values { if strings.Contains(value, expected) { return } }
	t.Fatalf("missing %q in %#v", expected, values)
}

func vaultProbe(t *testing.T) *Vault {
	t.Helper()
	dir := t.TempDir()
	return &Vault{dir: dir, registry: openRegistry(dir)}
}

func TestGRRRD023(t *testing.T) {
ranges := expandAndMerge([]int{0, 1}, 1, 3); if len(ranges) != 1 || ranges[0] != (lineRange{0, 2}) { t.Fatalf("adjacent ranges not merged: %#v", ranges) }
}
