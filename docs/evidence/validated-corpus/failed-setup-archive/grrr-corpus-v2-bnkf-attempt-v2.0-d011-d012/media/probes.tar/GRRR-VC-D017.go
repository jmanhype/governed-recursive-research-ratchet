package vlt

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

var _ = time.Second

func writeProbe(t *testing.T, path, content string) {
	t.Helper()
	if err := os.WriteFile(path, []byte(content), 0644); err != nil { t.Fatal(err) }
}

func requireProbe(t *testing.T, err error) {
	t.Helper()
	if err != nil { t.Fatal(err) }
}

func readFileProbe(t *testing.T, path string) string {
	t.Helper()
	data, err := os.ReadFile(path)
	if err != nil { t.Fatal(err) }
	return string(data)
}

func requireRelProbe(t *testing.T, root, path, expected string) {
	t.Helper()
	got, err := filepath.Rel(root, path)
	if err != nil { t.Fatal(err) }
	if filepath.ToSlash(got) != expected { t.Fatalf("path %q, want %q", got, expected) }
}

func requireContainsProbe(t *testing.T, values []string, expected string) {
	t.Helper()
	for _, value := range values { if strings.Contains(value, expected) { return } }
	t.Fatalf("missing %q in %#v", expected, values)
}

func vaultProbe(t *testing.T) *Vault {
	t.Helper()
	dir := t.TempDir()
	return &Vault{dir: dir, registry: openRegistry(dir)}
}

func TestGRRRD017(t *testing.T) {
v := vaultProbe(t); os.MkdirAll(filepath.Join(v.dir, "_inbox"), 0755); writeProbe(t, filepath.Join(v.dir, "_inbox", "Note.md"), "# Note"); writeProbe(t, filepath.Join(v.dir, "Ref.md"), "[[_inbox/Note]]\n")
_, err := v.Move("_inbox/Note.md", "decisions/Note.md"); requireProbe(t, err); requireContainsProbe(t, []string{readFileProbe(t, filepath.Join(v.dir, "Ref.md"))}, "[[decisions/Note]]")
}
